PartInfo is a simple mod to expose the internal part name and path to the part file.  

The data shows up in the VAB/SPH when you right-click on a part in the part list